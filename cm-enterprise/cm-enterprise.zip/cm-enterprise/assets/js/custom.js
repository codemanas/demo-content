(function (){
   const mobNavigation = () =>{
    const DOM = { }

    const cacheDOM =()=>{
      DOM.dropdownIcon = document.querySelector('.wp-block-navigation__submenu-icon');
      DOM.subMenuItems = document.querySelector('.wp-block-navigation__submenu-container')
    }

    const eventListeners=()=> {
      DOM.dropdownIcon.addEventListener('click', function (e) {
        e.preventDefault();
        DOM.subMenuItems.classList.toggle('is-subMenu--active');
      });
    }
    
    const init = () => {
      cacheDOM()
      eventListeners()
  }
  return { init }

   }
   document.addEventListener('DOMContentLoaded', mobNavigation().init)

});





