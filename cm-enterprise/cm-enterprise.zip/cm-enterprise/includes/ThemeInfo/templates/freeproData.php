<?php
$data = array(
    array(
        'free' => '<span class="dashicons dashicons-yes"></span>',
        'name' => 'Coming Soon',
        'pro' => '<span class="dashicons dashicons-no"></span>',
    )
    ,
    array(
        'free' => '<span class="dashicons dashicons-yes"></span>',
        'name' => 'Coming Soon',
        'pro' => '<span class="dashicons dashicons-no"></span>',
    )
);
?>