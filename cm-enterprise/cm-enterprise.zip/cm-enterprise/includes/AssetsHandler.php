<?php

namespace Codemanas\CMEnterprise;

class AssetsHandler {
	private static ?AssetsHandler $instance = null;

	public static function get_instance(): ?AssetsHandler {
		return is_null( self::$instance ) ? self::$instance = new self() : self::$instance;
	}

	private function __construct() {
		add_action( 'wp_enqueue_scripts', [$this,'register_editor_styles'] );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
	}

	public function admin_scripts( $hook ): void {
		// Correct the hook comparison and use get_template_directory_uri() for consistency
		if ( 'appearance_page_cm-enterprise-info' !== $hook ) {
			return;
		}

		$path = get_template_directory_uri() . '/assets/css/admin-style.css';
		$deps = array();
		wp_enqueue_style( 'cm-enterprise-admin-styles', $path, $deps, '1.0.2',
			'all' );
		wp_enqueue_script( 'cm_enterprise_admin_script',
			get_template_directory_uri() . '/assets/js/admin.js', array(),
			'1.0' );
	}

	public function register_editor_styles(): void {
		wp_register_style(
			'cm-enterprise-block-style',
			get_theme_file_uri( 'assets/css/style' . '.css' ),
			array(),
			CM_ENTERPRISE_VERSION
		);
		wp_enqueue_style( 'cm-enterprise-block-style' );

		wp_register_script(
			'cm-enterprise-custom-scripts',
			get_theme_file_uri( 'assets/js/custom' . '.js' ),
			array(),
			CM_ENTERPRISE_VERSION,
			true
		);
		wp_enqueue_script( 'cm-enterprise-custom-scripts' );
	}
}