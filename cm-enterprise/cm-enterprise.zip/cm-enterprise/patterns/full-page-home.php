<?php
/**
 * Title: Full Page Home
 * Slug: cm-enterprise/full-page-home
 * Categories: cm-enterprise-fullpage
 * Block Types: core/group, core/columns, core/image, core/cover, core/text, core/paragraph, codemanas/page
 * @package cm-enterprise
 * @since 1.0.0
 */
?>
<!-- wp:pattern {"slug":"cm-enterprise/banner"} /-->
<!-- wp:pattern {"slug":"cm-enterprise/clients"} /-->
<!-- wp:pattern {"slug":"cm-enterprise/about"} /-->
<!-- wp:pattern {"slug":"cm-enterprise/cta"} /-->
<!-- wp:pattern {"slug":"cm-enterprise/about-with-right-image"} /-->
<!-- wp:pattern {"slug":"cm-enterprise/teams"} /-->
<!-- wp:pattern {"slug":"cm-enterprise/service"} /-->
<!-- wp:pattern {"slug":"cm-enterprise/testimonials"} /-->


